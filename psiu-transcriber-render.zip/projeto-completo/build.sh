#!/bin/bash

echo "🚀 Iniciando build para Render..."

# Instalar dependências do backend
cd backend
npm install

echo "✅ Build concluído!"

